import api from './client';
import { ApiResponse, Lead, LeadFilters, LeadFormData, PaginationMeta, User, UserRole } from '../types';

// ─── Auth ────────────────────────────────────────────────────────────────────

interface AuthData { token: string; user: User }

export const authApi = {
  register: (name: string, email: string, password: string, role?: UserRole) =>
    api.post<ApiResponse<AuthData>>('/auth/register', { name, email, password, role }),

  login: (email: string, password: string) =>
    api.post<ApiResponse<AuthData>>('/auth/login', { email, password }),

  me: () =>
    api.get<ApiResponse<User>>('/auth/me'),
};

// ─── Leads ───────────────────────────────────────────────────────────────────

export const leadsApi = {
  getAll: (filters: LeadFilters) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== '') params.set(k, String(v));
    });
    return api.get<ApiResponse<Lead[]> & { meta: PaginationMeta }>(`/leads?${params}`);
  },

  getOne: (id: string) =>
    api.get<ApiResponse<Lead>>(`/leads/${id}`),

  create: (data: LeadFormData) =>
    api.post<ApiResponse<Lead>>('/leads', data),

  update: (id: string, data: Partial<LeadFormData>) =>
    api.put<ApiResponse<Lead>>(`/leads/${id}`, data),

  delete: (id: string) =>
    api.delete<ApiResponse<void>>(`/leads/${id}`),

  exportCSV: async (filters: Partial<LeadFilters>): Promise<void> => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== '') params.set(k, String(v));
    });
    const response = await api.get(`/leads/export?${params}`, { responseType: 'blob' });
    const url = URL.createObjectURL(new Blob([response.data]));
    const a = document.createElement('a');
    a.href = url;
    a.download = `leads-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  },
};
